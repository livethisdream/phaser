#!/bin/bash
set -e

INSTALL_DIR="/home/analog/pyadi-iio/examples/phaser"
SERVICE_NAME="phaser-headless"

echo "========================================"
echo "  Phaser Beamforming Installer"
echo "========================================"

# Check if running as analog user or root
if [[ $EUID -eq 0 ]]; then
    SUDO=""
else
    SUDO="sudo"
fi

echo ""
echo "[1/5] Installing Python dependencies..."
pip3 install --user pyzmq msgpack websockets 2>/dev/null || $SUDO pip3 install pyzmq msgpack websockets

echo ""
echo "[2/5] Copying backend..."
$SUDO mkdir -p "$INSTALL_DIR"
$SUDO cp phaser_headless.py "$INSTALL_DIR/"
$SUDO chown analog:analog "$INSTALL_DIR/phaser_headless.py"

echo ""
echo "[3/5] Copying frontend..."
$SUDO mkdir -p "$INSTALL_DIR/www"
$SUDO cp -r www/* "$INSTALL_DIR/www/"
$SUDO chown -R analog:analog "$INSTALL_DIR/www"

echo ""
echo "[4/5] Installing systemd service..."
$SUDO tee /etc/systemd/system/${SERVICE_NAME}.service > /dev/null << 'EOF'
[Unit]
Description=Phaser Headless Backend
After=network.target

[Service]
Type=simple
User=analog
WorkingDirectory=/home/analog/pyadi-iio/examples/phaser
ExecStart=/usr/bin/python3 -u /home/analog/pyadi-iio/examples/phaser/phaser_headless.py
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

$SUDO systemctl daemon-reload
$SUDO systemctl enable ${SERVICE_NAME}

echo ""
echo "[5/5] Starting service..."
$SUDO systemctl restart ${SERVICE_NAME}
sleep 2

if systemctl is-active --quiet ${SERVICE_NAME}; then
    IP=$(hostname -I | awk '{print $1}')
    echo ""
    echo "========================================"
    echo "  Installation Complete!"
    echo "========================================"
    echo ""
    echo "  Web UI:  http://${IP}:8080"
    echo ""
    echo "  Commands:"
    echo "    sudo systemctl status phaser-headless"
    echo "    sudo journalctl -u phaser-headless -f"
    echo ""
else
    echo ""
    echo "ERROR: Service failed to start"
    echo "Check: sudo journalctl -u phaser-headless -n 50"
    exit 1
fi
