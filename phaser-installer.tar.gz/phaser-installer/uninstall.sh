#!/bin/bash
echo "Stopping and removing phaser-headless service..."
sudo systemctl stop phaser-headless 2>/dev/null || true
sudo systemctl disable phaser-headless 2>/dev/null || true
sudo rm -f /etc/systemd/system/phaser-headless.service
sudo systemctl daemon-reload
echo "Done. Files in /home/analog/pyadi-iio/examples/phaser/ were not removed."
